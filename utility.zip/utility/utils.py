#could be used to further restructure and clean the code base
#it is not being used for now